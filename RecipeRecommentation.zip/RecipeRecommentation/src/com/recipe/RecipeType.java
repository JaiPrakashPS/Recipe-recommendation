// RecipeType.java
package com.recipe;

public enum RecipeType {
    VEGETARIAN,
    NON_VEGETARIAN
}
